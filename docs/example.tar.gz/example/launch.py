#!/usr/bin/env python3

from solverpy.benchmark import setups

mysetup = {
    "limit": "T1",
    "cores": 4,
    "bidlist": ["problems"],
    "sidlist": ["buzzard", "sparrow", "chickadee"],
    #"options": ["outputs"],

}

setups.cvc5(mysetup)
setups.evaluation(mysetup)
setups.launch(mysetup)


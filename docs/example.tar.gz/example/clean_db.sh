ls solverpy_db | grep -v strats | xargs -I{} rm -fr solverpy_db/{}

